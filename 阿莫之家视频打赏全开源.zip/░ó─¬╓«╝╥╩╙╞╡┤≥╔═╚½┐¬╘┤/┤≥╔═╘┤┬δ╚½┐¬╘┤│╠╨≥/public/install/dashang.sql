/*
Navicat MySQL Data Transfer

Source Server         : 39.107.90.248
Source Server Version : 50557
Source Host           : 39.107.90.248:3306
Source Database       : dsds_test_sdgtw

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2018-08-04 01:03:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `ds_admin`
-- ----------------------------
DROP TABLE IF EXISTS `ds_admin`;
CREATE TABLE `ds_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(50) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ds_admin
-- ----------------------------
INSERT INTO `ds_admin` VALUES ('1', 'admin', 'e3ef280185cda4d25ea99c552f0254fd', '20180626/67faa110f813108c3678432b995a8107.png', '318', '223.104.254.38', '1533315054', 'admin', '1', '1');
INSERT INTO `ds_admin` VALUES ('2', '1', '31605938c0c04ff6c96fb7d65e9cf3fa', '', '0', '', '0', '1', '1', '4');

-- ----------------------------
-- Table structure for `ds_auth_group`
-- ----------------------------
DROP TABLE IF EXISTS `ds_auth_group`;
CREATE TABLE `ds_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_auth_group
-- ----------------------------
INSERT INTO `ds_auth_group` VALUES ('1', '超级管理员', '1', '', '1446535750', '1446535750');
INSERT INTO `ds_auth_group` VALUES ('4', '1', '1', '', '1533308549', '1533308549');

-- ----------------------------
-- Table structure for `ds_auth_group_access`
-- ----------------------------
DROP TABLE IF EXISTS `ds_auth_group_access`;
CREATE TABLE `ds_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_auth_group_access
-- ----------------------------
INSERT INTO `ds_auth_group_access` VALUES ('2', '4');

-- ----------------------------
-- Table structure for `ds_auth_rule`
-- ----------------------------
DROP TABLE IF EXISTS `ds_auth_rule`;
CREATE TABLE `ds_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_auth_rule
-- ----------------------------
INSERT INTO `ds_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '1', '1446535750', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('2', 'dsadmin/user/index', '用户管理', '1', '1', '', '', '1', '10', '1446535750', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('3', 'dsadmin/role/index', '角色管理', '1', '1', '', '', '1', '20', '1446535750', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('122', 'dsadmin/gonggao/gonggao_tc', '公告弹窗', '1', '1', '', '', '54', '50', '1530820331', '1530820331');
INSERT INTO `ds_auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '2', '1446535750', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('6', 'dsadmin/data/index', '数据库备份', '1', '1', '', '', '5', '50', '1446535750', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('7', 'dsadmin/data/optimize', '优化表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('8', 'dsadmin/data/repair', '修复表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('9', 'dsadmin/user/useradd', '添加用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('10', 'dsadmin/user/useredit', '编辑用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('11', 'dsadmin/user/userdel', '删除用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('12', 'dsadmin/user/user_state', '用户状态', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('13', '#', '日志管理', '1', '1', 'fa fa-tasks', '', '0', '6', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('14', 'dsadmin/log/operate_log', '行为日志', '1', '1', '', '', '13', '50', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('22', 'dsadmin/log/del_log', '删除日志', '1', '1', '', '', '14', '50', '1477312169', '1477316778');
INSERT INTO `ds_auth_rule` VALUES ('24', '#', '资源管理', '1', '1', 'fa fa-paste', '', '0', '3', '1477312169', '1477312169');
INSERT INTO `ds_auth_rule` VALUES ('109', 'dsadmin/dlmenu/giveAccess', '代理权限获取', '1', '1', '', '', '87', '50', '1530300523', '1530300523');
INSERT INTO `ds_auth_rule` VALUES ('26', 'dsadmin/gongyou/index', '公共片库', '1', '1', '', '', '24', '20', '1477312333', '1477312333');
INSERT INTO `ds_auth_rule` VALUES ('27', 'dsadmin/data/import', '数据库还原', '1', '1', '', '', '5', '50', '1477639870', '1477639870');
INSERT INTO `ds_auth_rule` VALUES ('28', 'dsadmin/data/revert', '还原', '1', '1', '', '', '27', '50', '1477639972', '1477639972');
INSERT INTO `ds_auth_rule` VALUES ('29', 'dsadmin/data/del', '删除', '1', '1', '', '', '27', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('30', 'dsadmin/role/roleAdd', '添加角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('31', 'dsadmin/role/roleEdit', '编辑角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('32', 'dsadmin/role/roleDel', '删除角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('33', 'dsadmin/role/role_state', '角色状态', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('34', 'dsadmin/role/giveAccess', '权限分配', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('35', 'dsadmin/menu/add_rule', '添加菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('36', 'dsadmin/menu/edit_rule', '编辑菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('37', 'dsadmin/menu/del_rule', '删除菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('38', 'dsadmin/menu/rule_state', '菜单状态', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('39', 'dsadmin/menu/ruleorder', '菜单排序', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('108', 'dsadmin/config/save', '配置保存', '1', '1', '', '', '66', '50', '1530300338', '1530300338');
INSERT INTO `ds_auth_rule` VALUES ('105', 'dsadmin/gongyou/add', '添加视频外链', '1', '1', '', '', '24', '50', '1530132392', '1530132392');
INSERT INTO `ds_auth_rule` VALUES ('106', 'dsadmin/siyou/index', '代理片库', '1', '1', '', '', '24', '21', '1530132484', '1530132484');
INSERT INTO `ds_auth_rule` VALUES ('44', 'dsadmin/gongyou/shangchuan', '上传本地视频', '1', '1', '', '', '24', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('45', 'dsadmin/gongyou/edit', '编辑公共片库', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('46', 'dsadmin/gongyou/del', '删除公共片库', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('107', 'dsadmin/siyou/del', '删除代理片库', '1', '1', '', '', '106', '50', '1530132515', '1530132515');
INSERT INTO `ds_auth_rule` VALUES ('88', 'dsadmin/tousu/index', '投诉列表', '1', '1', '', '', '1', '50', '1529961583', '1529961583');
INSERT INTO `ds_auth_rule` VALUES ('89', 'dsadmin/tousu/yx', '允许该IP访问', '1', '1', '', '', '88', '50', '1529961622', '1529961622');
INSERT INTO `ds_auth_rule` VALUES ('90', 'dsadmin/tousu/jz', '禁止该IP访问', '1', '1', '', '', '88', '50', '1529961668', '1529961668');
INSERT INTO `ds_auth_rule` VALUES ('54', 'dsadmin/gonggao/index', '公告列表', '1', '1', '', '', '1', '20', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('55', 'dsadmin/gonggao/add_gonggao', '添加公告', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('56', 'dsadmin/gonggao/edit_gonggao', '编辑公告', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('57', 'dsadmin/gonggao/del_gonggao', '删除公告', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('58', 'dsadmin/gonggao/gonggao_state', '公告状态', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `ds_auth_rule` VALUES ('62', 'dsadmin/config/add_config', '添加配置', '1', '1', '', '', '61', '50', '1479908607', '1479908607');
INSERT INTO `ds_auth_rule` VALUES ('63', 'dsadmin/config/edit_config', '编辑配置', '1', '1', '', '', '61', '50', '1479908607', '1479908607');
INSERT INTO `ds_auth_rule` VALUES ('64', 'dsadmin/config/del_config', '删除配置', '1', '1', '', '', '61', '50', '1479908607', '1479908607');
INSERT INTO `ds_auth_rule` VALUES ('65', 'dsadmin/config/status_config', '配置状态', '1', '1', '', '', '61', '50', '1479908607', '1479908607');
INSERT INTO `ds_auth_rule` VALUES ('66', 'dsadmin/config/group', '网站配置', '1', '1', '', '', '1', '50', '1480316438', '1480316438');
INSERT INTO `ds_auth_rule` VALUES ('70', '#', '代理管理', '1', '1', 'fa fa-users', '', '0', '3', '1484103066', '1529874573');
INSERT INTO `ds_auth_rule` VALUES ('84', 'dsadmin/ename/del', '删除域名', '1', '1', '', '', '81', '50', '1529949335', '1529949335');
INSERT INTO `ds_auth_rule` VALUES ('81', 'dsadmin/ename/index', '打赏域名列表', '1', '1', '', '', '1', '50', '1529949266', '1529949266');
INSERT INTO `ds_auth_rule` VALUES ('82', 'dsadmin/ename/add', '添加域名', '1', '1', '', '', '81', '50', '1529949295', '1529949295');
INSERT INTO `ds_auth_rule` VALUES ('83', 'dsadmin/ename/edit', '修改域名', '1', '1', '', '', '81', '50', '1529949314', '1529949314');
INSERT INTO `ds_auth_rule` VALUES ('75', 'dsadmin/member/index', '代理列表', '1', '1', '', '', '70', '20', '1484103304', '1484103304');
INSERT INTO `ds_auth_rule` VALUES ('76', 'dsadmin/member/add_member', '添加代理', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `ds_auth_rule` VALUES ('77', 'dsadmin/member/edit_member', '编辑代理', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `ds_auth_rule` VALUES ('78', 'dsadmin/member/del_member', '删除代理', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `ds_auth_rule` VALUES ('79', 'dsadmin/member/member_status', '代理状态', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `ds_auth_rule` VALUES ('85', 'dsadmin/ename/status', '域名状态', '1', '1', '', '', '81', '50', '1529949374', '1529949374');
INSERT INTO `ds_auth_rule` VALUES ('87', 'dsadmin/dlmenu/index2', '代理权限分配', '1', '1', '', '', '1', '50', '1529953615', '1529953615');
INSERT INTO `ds_auth_rule` VALUES ('91', 'dsadmin/tousu/del', '删除投诉', '1', '1', '', '', '88', '50', '1529961707', '1529961707');
INSERT INTO `ds_auth_rule` VALUES ('92', 'dsadmin/kouliang/index', '扣量设置', '1', '1', '', '', '1', '50', '1529991166', '1529991236');
INSERT INTO `ds_auth_rule` VALUES ('93', 'dsadmin/kouliang/add', '添加扣量', '1', '1', '', '', '92', '50', '1529991216', '1529991216');
INSERT INTO `ds_auth_rule` VALUES ('94', 'dsadmin/kouliang/edit', '修改扣量', '1', '1', '', '', '92', '50', '1529991286', '1529991286');
INSERT INTO `ds_auth_rule` VALUES ('95', 'dsadmin/kouliang/del', '删除扣量', '1', '1', '', '', '92', '50', '1529991344', '1529991344');
INSERT INTO `ds_auth_rule` VALUES ('96', 'dsadmin/yqm/index', '邀请码管理', '1', '1', '', '', '70', '50', '1530044730', '1530044730');
INSERT INTO `ds_auth_rule` VALUES ('97', 'dsadmin/yqm/shengcheng', '生成邀请码', '1', '1', '', '', '96', '50', '1530044769', '1530044769');
INSERT INTO `ds_auth_rule` VALUES ('98', 'dsadmin/yqm/add', '添加邀请码', '1', '1', '', '', '96', '50', '1530044800', '1530044800');
INSERT INTO `ds_auth_rule` VALUES ('99', 'dsadmin/yqm/del', '删除邀请码', '1', '1', '', '', '96', '50', '1530044947', '1530044947');
INSERT INTO `ds_auth_rule` VALUES ('100', '#', '订单管理', '1', '1', 'fa fa-tasks', '', '0', '4', '1530047792', '1530048333');
INSERT INTO `ds_auth_rule` VALUES ('101', 'dsadmin/order/index', '订单列表', '1', '1', '', '', '100', '1', '1530047822', '1530047822');
INSERT INTO `ds_auth_rule` VALUES ('102', 'dsadmin/pay/index', '未结算记录', '1', '1', '', '', '100', '2', '1530047871', '1530047871');
INSERT INTO `ds_auth_rule` VALUES ('103', 'dsadmin/pay/yjs', '已结算记录', '1', '1', '', '', '100', '3', '1530047904', '1530047904');
INSERT INTO `ds_auth_rule` VALUES ('104', 'dsadmin/pay/dakuan', '确认打款', '1', '1', '', '', '102', '50', '1530121373', '1530121373');
INSERT INTO `ds_auth_rule` VALUES ('110', 'dsadmin/dlmenu/add_rule', '添加', '1', '1', '', '', '86', '50', '1530300617', '1530300617');
INSERT INTO `ds_auth_rule` VALUES ('111', 'dsadmin/dlmenu/edit_rule', '修改', '1', '1', '', '', '86', '50', '1530300662', '1530300662');
INSERT INTO `ds_auth_rule` VALUES ('112', 'dsadmin/dlmenu/del_rule', '删除', '1', '1', '', '', '86', '50', '1530300687', '1530300687');
INSERT INTO `ds_auth_rule` VALUES ('113', 'dsadmin/upload/uploadface', '上传头像', '1', '1', '', '', '75', '50', '1530304207', '1530304207');
INSERT INTO `ds_auth_rule` VALUES ('114', 'dsadmin/upload/uploadshipin', '上传视频', '1', '1', '', '', '44', '50', '1530304346', '1530304346');
INSERT INTO `ds_auth_rule` VALUES ('115', 'dsadmin/siyou/editprice', '修改价格', '1', '1', '', '', '106', '50', '1530466241', '1530466241');
INSERT INTO `ds_auth_rule` VALUES ('116', 'dsadmin/zhifu/index', '支付配置', '1', '1', '', '', '1', '50', '1530798255', '1530798255');
INSERT INTO `ds_auth_rule` VALUES ('117', 'dsadmin/kouliang/lists', '扣量列表', '1', '1', '', '', '1', '50', '1530816646', '1530816646');
INSERT INTO `ds_auth_rule` VALUES ('119', 'dsadmin/tupian/index', '随机图片列表', '1', '1', '', '', '1', '50', '1530820308', '1530820308');
INSERT INTO `ds_auth_rule` VALUES ('120', 'dsadmin/tupian/add', '添加图片', '1', '1', '', '', '119', '50', '1530820331', '1530820331');
INSERT INTO `ds_auth_rule` VALUES ('121', 'dsadmin/tupian/del', '删除图片', '1', '1', '', '', '119', '50', '1530820349', '1530820349');
INSERT INTO `ds_auth_rule` VALUES ('131', 'dsadmin/order/search', '时间搜索', '1', '1', '', '', '101', '50', '1531320438', '1531320438');
INSERT INTO `ds_auth_rule` VALUES ('132', 'dsadmin/upload/upload', '上传图片', '1', '1', '', '', '44', '50', '1532794397', '1532794397');
INSERT INTO `ds_auth_rule` VALUES ('133', 'dsadmin/upload/upload', '上传图片', '1', '1', '', '', '105', '50', '1532794428', '1532794428');

-- ----------------------------
-- Table structure for `ds_config`
-- ----------------------------
DROP TABLE IF EXISTS `ds_config`;
CREATE TABLE `ds_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `group` (`group`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_config
-- ----------------------------
INSERT INTO `ds_config` VALUES ('1', 'web_site_title', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1480575456', '1', '诺诺打赏', '0');
INSERT INTO `ds_config` VALUES ('41', 'txzdje', '0', '提现最低金额设置', '3', '', '说明：此项功能是设置代理最低的提现金额', '1529945933', '1529945933', '1', '100', '0');
INSERT INTO `ds_config` VALUES ('4', 'web_site_close', '4', '站点状态', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1480643099', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('9', 'config_type_list', '3', '配置类型列表', '4', '0:数字,\n1:字符,\n2:文本,\n3:数组\n,4:枚举', '主要用于数据解析和页面表单的生成', '1378898976', '1529947943', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '0');
INSERT INTO `ds_config` VALUES ('42', 'yhtxfl', '0', '用户提现费率设置', '3', '', '说明：此项功能是设置注册时代理默认提现费率', '1529945997', '1529945997', '1', '15', '0');
INSERT INTO `ds_config` VALUES ('20', 'config_group_list', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:网站\r\n3:用户\r\n4:系统\r\n5:防封\r\n6:提示语设置', '4');
INSERT INTO `ds_config` VALUES ('22', 'auth_config', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `ds_config` VALUES ('25', 'list_rows', '0', '代理后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1529946590', '1', '10', '0');
INSERT INTO `ds_config` VALUES ('26', 'user_allow_register', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `ds_config` VALUES ('28', 'data_backup_path', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './data/', '5');
INSERT INTO `ds_config` VALUES ('29', 'data_backup_part_size', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `ds_config` VALUES ('30', 'data_backup_compress', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `ds_config` VALUES ('31', 'data_backup_compress_level', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `ds_config` VALUES ('36', 'admin_allow_ip', '2', '禁止后台访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1480643409', '1', '0.0.0.0', '0');
INSERT INTO `ds_config` VALUES ('44', 'fyzdje', '0', '返佣最低金额起效', '3', '', '说明：此项功能是设置代理下级满足条件上级可返佣', '1529946094', '1529946094', '1', '100', '0');
INSERT INTO `ds_config` VALUES ('43', 'yhfybl', '0', '用户返佣比例设置', '3', '', '说明：此项功能是设置用户返佣比例功能', '1529946034', '1529946034', '1', '10', '0');
INSERT INTO `ds_config` VALUES ('62', 'dlskms', '4', '代理提现模式', '3', '0:账户加二维码\n1:账户\n2:二维码', '代理提现账户类型设置', '1530109001', '1530585493', '1', '0', '0');
INSERT INTO `ds_config` VALUES ('45', 'mrtxzgje', '0', '每日提现最高金额', '3', '', '说明：此项功能是设置每日提现上限', '1529946128', '1529946128', '1', '10000', '0');
INSERT INTO `ds_config` VALUES ('46', 'aqtxje', '0', '安全提现金额设置', '3', '', '说明：此项功能是设置代理提现单笔金额', '1529946171', '1529946171', '1', '2000', '0');
INSERT INTO `ds_config` VALUES ('47', 'yqmjiage', '0', '邀请码收费标准', '3', '', '说明：此项功能是设置邀请码购买的价格', '1529946263', '1529946263', '1', '0', '0');
INSERT INTO `ds_config` VALUES ('48', 'fbspsz', '4', '发布视频设置', '2', '0:禁止用户发布视频\n1:允许用户发布视频', '发布视频设置', '1529946479', '1529946514', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('49', 'zfjk', '4', '支付接口', '2', '1:公众号支付\n2:U支付\n3:云支付\n4:摩登支付', '支付接口', '1529946775', '1530820210', '1', '4', '0');
INSERT INTO `ds_config` VALUES ('50', 'dsklsz', '4', '打赏扣量设置', '2', '0:关闭扣量\n1:开启扣量', '打赏扣量设置', '1529946857', '1529946939', '1', '0', '0');
INSERT INTO `ds_config` VALUES ('51', 'wyywsz', '4', '我也要玩设置', '2', '0:显示我也要玩按钮\n1:显示更多视频按钮', '我也要玩设置', '1529946929', '1529946929', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('52', 'dnfwkg', '4', '电脑访问开关', '2', '0:不允许电脑访问\n1:允许电脑访问', '电脑访问开关', '1529946989', '1529946989', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('53', 'dnfwtz', '1', '电脑访问跳转', '2', '', '电脑访问跳转', '1529947031', '1529947031', '1', 'http://www.baidu.com', '0');
INSERT INTO `ds_config` VALUES ('54', 'ksymkg', '4', '打赏域名开关', '5', '0:关闭多域名随机调用\n1:开启多域名随机调用', '打赏域名开关', '1529947161', '1529947161', '1', '0', '0');
INSERT INTO `ds_config` VALUES ('55', 'ffymkg', '4', '防封域名开关', '5', '0:关闭\n1:开启', '防封域名开关', '1529947351', '1529947351', '1', '0', '0');
INSERT INTO `ds_config` VALUES ('56', 'ffymsz', '1', '防封域名设置', '5', '', '防封域名设置', '1529947397', '1529947397', '1', 'http://dsds.test.sdgtwz.com', '0');
INSERT INTO `ds_config` VALUES ('57', 'dwzjk', '4', '短网址接口', '5', '3:c7.gg\n4:kks.me\n5:rrd.me\n6:uee.me\n7:6du.in\n8:mrw.so\n9:u6.gg\n10:t.cn', '短网址接口', '1529947534', '1530478033', '1', '10', '0');
INSERT INTO `ds_config` VALUES ('58', 'tsybt', '1', '标题提示', '6', '', '前台私有片库批量复制标题提示', '1529948698', '1529948728', '1', '[ 微信红包 ] 恭喜发财 大吉大利', '0');
INSERT INTO `ds_config` VALUES ('59', 'tsyzbts', '1', '中部提示', '6', '', '前台私有片库批量复制中部提示', '1529948783', '1529948783', '1', '打赏后如无跳转视频, 重新从链接进入即可观看', '0');
INSERT INTO `ds_config` VALUES ('60', 'tsyjwts', '1', '结尾提示', '6', '', '前台私有片库批量复制结尾提示', '1529948862', '1529948862', '1', '诈骗死全家', '0');
INSERT INTO `ds_config` VALUES ('61', 'zzwxh', '1', '客服微信号', '1', '', '客服微信号', '1529948925', '1529948966', '1', '微信号', '0');
INSERT INTO `ds_config` VALUES ('63', 'dlyulan', '4', '代理预览设置', '2', '1:可预览\n0:不可预览', '代理预览设置', '1530300055', '1530300055', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('64', 'dlspggpk', '4', '代理上传的视频加入公共片库', '2', '1:是\n0:否', '代理上传的视频加入公共片库', '1530479964', '1530484251', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('65', 'dltjwlggpk', '4', '代理外链是否加入公共片库', '2', '0:否\n1:是', '代理外链是否加入公共片库', '1530484242', '1530484242', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('66', 'dlzdsps', '0', '代理最多视频数', '2', '', '每个代理最多发布多少个视频', '1530516531', '1530516531', '1', '100', '0');
INSERT INTO `ds_config` VALUES ('67', 'ffhouzhui', '1', '防封后缀', '5', '', '防封跳转后缀', '1530707627', '1530707651', '1', 'shipintg.html', '0');
INSERT INTO `ds_config` VALUES ('68', 'zuidijiage', '0', '最低价格', '3', '', '发布打赏最低不能小于多少元', '1530814024', '1530814024', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('69', 'zuidajiage', '0', '最大价格', '3', '', '发布打赏最高不能大于多少元', '1530814071', '1530814071', '1', '15', '0');
INSERT INTO `ds_config` VALUES ('71', 'guoqitime', '0', '支付后可观看时长', '3', '', '支付后多少小时不用重新收费', '1530976383', '1530976383', '1', '24', '0');
INSERT INTO `ds_config` VALUES ('72', 'sfkqsims', '4', '是否开启随机金额', '3', '0:开启\n1:不开启', '是否开启随机金额', '1530981457', '1530981457', '1', '1', '0');
INSERT INTO `ds_config` VALUES ('73', 'zhifuxianshi', '1', '支付显示', '2', '', '支付显示', '1531688038', '1531688038', '1', 'vip', '0');

-- ----------------------------
-- Table structure for `ds_dingdan`
-- ----------------------------
DROP TABLE IF EXISTS `ds_dingdan`;
CREATE TABLE `ds_dingdan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL COMMENT '用户ID',
  `zyid` varchar(255) DEFAULT NULL COMMENT '资源ID',
  `zymc` varchar(255) DEFAULT NULL COMMENT '资源名称',
  `money` varchar(255) DEFAULT NULL COMMENT '打赏金额',
  `shijian` varchar(255) DEFAULT NULL COMMENT '打赏时间',
  `ddh` varchar(255) DEFAULT NULL COMMENT '订单号',
  `wxddh` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `suoyin1` (`ddh`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_dingdan
-- ----------------------------

-- ----------------------------
-- Table structure for `ds_dlauth_group`
-- ----------------------------
DROP TABLE IF EXISTS `ds_dlauth_group`;
CREATE TABLE `ds_dlauth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_dlauth_group
-- ----------------------------
INSERT INTO `ds_dlauth_group` VALUES ('1', '代理中心', '1', '87,88,116,90,91,92,93,117,94,95,96,97,112,98,99,100,101,102,104,103,105,106,107,108,109,110,111,113,114,115,118,119,120,121,122', '1446535750', '1446535750');

-- ----------------------------
-- Table structure for `ds_dlauth_rule`
-- ----------------------------
DROP TABLE IF EXISTS `ds_dlauth_rule`;
CREATE TABLE `ds_dlauth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_dlauth_rule
-- ----------------------------
INSERT INTO `ds_dlauth_rule` VALUES ('87', '#', '开始赚钱', '1', '1', 'fa fa-database', '', '0', '11', '1529953375', '1530196455');
INSERT INTO `ds_dlauth_rule` VALUES ('88', 'daili/gongyou/index', '公共片库', '1', '1', '', '', '87', '1', '1529955562', '1530295515');
INSERT INTO `ds_dlauth_rule` VALUES ('90', 'daili/siyou/index', '私有片库', '1', '1', '', '', '87', '2', '1530464008', '1530464008');
INSERT INTO `ds_dlauth_rule` VALUES ('91', 'daili/siyou/del', '删除私有', '1', '1', '', '', '90', '50', '1530464045', '1530464045');
INSERT INTO `ds_dlauth_rule` VALUES ('92', 'daili/siyou/editprice', '修改价格', '1', '1', '', '', '90', '50', '1530464120', '1530464130');
INSERT INTO `ds_dlauth_rule` VALUES ('93', 'daili/siyou/edittitle', '修改标题', '1', '1', '', '', '90', '50', '1530471958', '1530471958');
INSERT INTO `ds_dlauth_rule` VALUES ('94', 'daili/siyou/fabushipin', '发布视频', '1', '1', '', '', '87', '3', '1530478246', '1530478246');
INSERT INTO `ds_dlauth_rule` VALUES ('95', 'daili/upload/uploadshipin', '上传视频', '1', '1', '', '', '94', '50', '1530479822', '1530479822');
INSERT INTO `ds_dlauth_rule` VALUES ('96', 'daili/siyou/wailian', '添加外链', '1', '1', '', '', '87', '4', '1530484093', '1530484093');
INSERT INTO `ds_dlauth_rule` VALUES ('97', 'daili/siyou/wodelianjie', '我的链接', '1', '1', '', '', '87', '5', '1530485284', '1530485284');
INSERT INTO `ds_dlauth_rule` VALUES ('98', '#', '收入明细', '1', '1', 'fa fa-tasks', '', '0', '50', '1530517683', '1530517715');
INSERT INTO `ds_dlauth_rule` VALUES ('99', 'daili/mingxi/dsjl', '打赏记录', '1', '1', '', '', '98', '50', '1530517810', '1530517810');
INSERT INTO `ds_dlauth_rule` VALUES ('100', 'daili/mingxi/dstj', '打赏统计', '1', '1', '', '', '98', '50', '1530517853', '1530517853');
INSERT INTO `ds_dlauth_rule` VALUES ('101', '#', '财务管理', '1', '1', 'fa fa-paste', '', '0', '50', '1530521958', '1530521966');
INSERT INTO `ds_dlauth_rule` VALUES ('102', 'daili/caiwu/sqtixian', '申请提现', '1', '1', '', '', '101', '50', '1530521992', '1530521992');
INSERT INTO `ds_dlauth_rule` VALUES ('103', 'daili/caiwu/jilu', '提现记录', '1', '1', '', '', '101', '50', '1530522011', '1530522011');
INSERT INTO `ds_dlauth_rule` VALUES ('104', 'daili/upload/upload', '上传收款码', '1', '1', '', '', '102', '50', '1530600986', '1530600986');
INSERT INTO `ds_dlauth_rule` VALUES ('105', '#', '用户信息', '1', '1', 'fa fa-users', '', '0', '50', '1530608070', '1530608070');
INSERT INTO `ds_dlauth_rule` VALUES ('106', 'daili/user/index', '基本资料', '1', '1', '', '', '105', '50', '1530608114', '1530608114');
INSERT INTO `ds_dlauth_rule` VALUES ('107', 'daili/upload/uploadface', '上传头像', '1', '1', '', '', '106', '50', '1530608165', '1530608165');
INSERT INTO `ds_dlauth_rule` VALUES ('108', 'daili/user/xiaji', '下级用户', '1', '1', '', '', '105', '50', '1530608193', '1530608193');
INSERT INTO `ds_dlauth_rule` VALUES ('109', 'daili/user/yqm', '邀请码管理', '1', '1', '', '', '105', '50', '1530608229', '1530608229');
INSERT INTO `ds_dlauth_rule` VALUES ('110', 'daili/user/yqmbuy', '购买邀请码', '1', '1', '', '', '109', '50', '1530608283', '1530608283');
INSERT INTO `ds_dlauth_rule` VALUES ('111', 'daili/user/fanyong', '返佣明细', '1', '1', '', '', '105', '50', '1530608314', '1530608314');
INSERT INTO `ds_dlauth_rule` VALUES ('112', 'daili/user/shuoming', '用户说明', '1', '1', '', '', '87', '50', '1530609544', '1530609544');
INSERT INTO `ds_dlauth_rule` VALUES ('113', '#', '系统公告', '1', '1', 'fa fa-gear', '', '0', '50', '1530653879', '1530654008');
INSERT INTO `ds_dlauth_rule` VALUES ('114', 'daili/gonggao/index', '公告列表', '1', '1', '', '', '113', '50', '1530653912', '1530654027');
INSERT INTO `ds_dlauth_rule` VALUES ('115', 'daili/gonggao/read', '查看公告', '1', '1', '', '', '114', '50', '1530654042', '1530654042');
INSERT INTO `ds_dlauth_rule` VALUES ('116', 'daili/gongyou/read', '查看视频', '1', '1', '', '', '88', '50', '1530661184', '1530661184');
INSERT INTO `ds_dlauth_rule` VALUES ('117', 'daili/siyou/read', '查看视频', '1', '1', '', '', '90', '50', '1530662255', '1530662255');
INSERT INTO `ds_dlauth_rule` VALUES ('118', '#', '推广盒子', '1', '1', 'fa fa-car', '', '0', '50', '1530685161', '1530685249');
INSERT INTO `ds_dlauth_rule` VALUES ('119', 'daili/tuiguang/index', '推广盒子', '1', '1', '', '', '118', '50', '1530685274', '1530685274');
INSERT INTO `ds_dlauth_rule` VALUES ('122', 'daili/tuiguang/del', '删除', '1', '1', '', '', '119', '50', '1530685161', '1530685161');
INSERT INTO `ds_dlauth_rule` VALUES ('121', 'daili/tuiguang/edit', '修改', '1', '1', '', '', '119', '50', '1530685161', '1530685161');
INSERT INTO `ds_dlauth_rule` VALUES ('120', 'daili/tuiguang/add', '添加', '1', '1', '', '', '119', '50', '1530685161', '1530685161');
INSERT INTO `ds_dlauth_rule` VALUES ('123', 'daili/upload/uploadshipin', '上传图片', '1', '1', '', '', '94', '50', '1532794461', '1532794461');
INSERT INTO `ds_dlauth_rule` VALUES ('124', 'dsadmin/upload/upload', '上传图片', '1', '1', '', '', '96', '50', '1532794474', '1532794474');

-- ----------------------------
-- Table structure for `ds_ename`
-- ----------------------------
DROP TABLE IF EXISTS `ds_ename`;
CREATE TABLE `ds_ename` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ename` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ds_ename
-- ----------------------------
INSERT INTO `ds_ename` VALUES ('10000', 'dsds.test.sdgtwz.com', '1');

-- ----------------------------
-- Table structure for `ds_fanyong`
-- ----------------------------
DROP TABLE IF EXISTS `ds_fanyong`;
CREATE TABLE `ds_fanyong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shijian` varchar(255) DEFAULT NULL,
  `fymoney` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `money2` varchar(255) DEFAULT NULL,
  `tjr` varchar(255) DEFAULT NULL,
  `txuserid` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_fanyong
-- ----------------------------

-- ----------------------------
-- Table structure for `ds_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `ds_gonggao`;
CREATE TABLE `ds_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `closed` tinyint(1) DEFAULT '0',
  `content` text,
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT NULL,
  `tanchuang` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_gonggao
-- ----------------------------
INSERT INTO `ds_gonggao` VALUES ('10000', '1', '1', '0', '<p>1</p>', '1533308568', '1533308568', '1');

-- ----------------------------
-- Table structure for `ds_gongyou`
-- ----------------------------
DROP TABLE IF EXISTS `ds_gongyou`;
CREATE TABLE `ds_gongyou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cs` int(10) DEFAULT '0' COMMENT '打赏人数',
  `url` varchar(1000) DEFAULT NULL COMMENT '打赏图片',
  `name` varchar(255) DEFAULT NULL COMMENT '资源名称',
  `shijian` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10006 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_gongyou
-- ----------------------------
INSERT INTO `ds_gongyou` VALUES ('10004', '0', '1', '1', '2018-08-03 22:58:04', '1');
INSERT INTO `ds_gongyou` VALUES ('10005', '0', '1', '1', '2018-08-03 23:05:36', '1');

-- ----------------------------
-- Table structure for `ds_ip`
-- ----------------------------
DROP TABLE IF EXISTS `ds_ip`;
CREATE TABLE `ds_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(100) DEFAULT NULL,
  `userid` int(10) DEFAULT NULL,
  `zyid` int(10) DEFAULT NULL,
  `ddh` varchar(100) DEFAULT NULL,
  `ddh2` varchar(255) DEFAULT NULL,
  `zt` varchar(255) DEFAULT NULL,
  `shijian` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `suoyin1` (`zyid`,`userid`,`ddh`,`ip`,`shijian`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_ip
-- ----------------------------

-- ----------------------------
-- Table structure for `ds_kl`
-- ----------------------------
DROP TABLE IF EXISTS `ds_kl`;
CREATE TABLE `ds_kl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `ddh` varchar(255) DEFAULT NULL,
  `qudao` varchar(255) DEFAULT NULL,
  `money` varchar(255) DEFAULT NULL,
  `shijian` varchar(255) DEFAULT NULL,
  `zymc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `suoyin1` (`ddh`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_kl
-- ----------------------------

-- ----------------------------
-- Table structure for `ds_kou`
-- ----------------------------
DROP TABLE IF EXISTS `ds_kou`;
CREATE TABLE `ds_kou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL,
  `cs` int(10) DEFAULT NULL,
  `ns` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10004 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_kou
-- ----------------------------
INSERT INTO `ds_kou` VALUES ('10002', '10003', '10', '30');
INSERT INTO `ds_kou` VALUES ('10003', '10004', '10', '30');

-- ----------------------------
-- Table structure for `ds_log`
-- ----------------------------
DROP TABLE IF EXISTS `ds_log`;
CREATE TABLE `ds_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10026 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_log
-- ----------------------------
INSERT INTO `ds_log` VALUES ('10010', '1', 'admin', '用户【admin】登录成功', '39.82.174.51', '1', '1530978278');
INSERT INTO `ds_log` VALUES ('10011', '1', 'admin', '用户【admin】登录成功', '39.82.174.51', '1', '1532793896');
INSERT INTO `ds_log` VALUES ('10012', '1', 'admin', '用户【admin】添加菜单成功', '39.82.174.51', '1', '1532794398');
INSERT INTO `ds_log` VALUES ('10013', '1', 'admin', '用户【admin】添加菜单成功', '39.82.174.51', '1', '1532794429');
INSERT INTO `ds_log` VALUES ('10014', '1', 'admin', '用户【admin】添加代理菜单成功', '39.82.174.51', '1', '1532794461');
INSERT INTO `ds_log` VALUES ('10015', '1', 'admin', '用户【admin】添加代理菜单成功', '39.82.174.51', '1', '1532794474');
INSERT INTO `ds_log` VALUES ('10016', '1', 'admin', '用户【admin】登录成功', '123.233.94.140', '1', '1533304128');
INSERT INTO `ds_log` VALUES ('10017', '1', 'admin', '', '123.233.94.140', '1', '1533307573');
INSERT INTO `ds_log` VALUES ('10018', '1', 'admin', '', '123.233.94.140', '1', '1533307645');
INSERT INTO `ds_log` VALUES ('10019', '1', 'admin', '用户【admin】登录成功', '123.233.94.140', '1', '1533307859');
INSERT INTO `ds_log` VALUES ('10020', '1', 'admin', '用户【1】添加成功', '123.233.94.140', '1', '1533308560');
INSERT INTO `ds_log` VALUES ('10021', '1', 'admin', '用户【admin】登录成功', '219.136.205.189', '1', '1533310389');
INSERT INTO `ds_log` VALUES ('10022', '1', 'admin', '用户【admin】登录成功', '219.136.205.189', '1', '1533310748');
INSERT INTO `ds_log` VALUES ('10023', '1', 'admin', '域名【dsds.test.sdgtwz.com55】添加成功', '219.136.205.189', '1', '1533311110');
INSERT INTO `ds_log` VALUES ('10024', '1', 'admin', '域名【dsds.test.sdgtwz.com】编辑成功', '219.136.205.189', '1', '1533311308');
INSERT INTO `ds_log` VALUES ('10025', '1', 'admin', '用户【admin】登录成功', '223.104.254.38', '1', '1533315054');

-- ----------------------------
-- Table structure for `ds_member`
-- ----------------------------
DROP TABLE IF EXISTS `ds_member`;
CREATE TABLE `ds_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) DEFAULT NULL COMMENT '邮件或者手机',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `password` varchar(255) DEFAULT NULL,
  `head_img` varchar(128) DEFAULT NULL COMMENT '头像',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '账户余额',
  `qq` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT '0' COMMENT '注册时间',
  `update_time` int(11) DEFAULT NULL COMMENT '最后一次登录',
  `login_num` int(15) DEFAULT '0' COMMENT '登录次数',
  `status` tinyint(1) DEFAULT '0' COMMENT '1激活  0 未激活',
  `closed` tinyint(1) DEFAULT '0',
  `weixin` varchar(255) DEFAULT '0',
  `txfeilv` decimal(10,2) DEFAULT '0.00',
  `skewm` varchar(255) DEFAULT NULL,
  `txmoney` decimal(10,2) DEFAULT '0.00',
  `pid` int(10) DEFAULT '0',
  `last_login_ip` varchar(255) DEFAULT NULL,
  `last_login_time` int(11) DEFAULT '0',
  `syyqm` varchar(255) DEFAULT NULL,
  `shipinurl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10006 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_member
-- ----------------------------
INSERT INTO `ds_member` VALUES ('10004', '1', '1', '1', '', '0.00', '', '1533307534', '1533308400', '2', '1', '0', '', '0.00', null, '0.00', '0', '123.233.94.140', '1533308194', null, null);
INSERT INTO `ds_member` VALUES ('10005', 'yuyusqq', '测试', '411848245..', '/static/admin/images/head_default.gif', '0.00', null, '1533310910', '1533310910', '1', '1', '0', '0', '15.00', null, '0.00', '10004', '219.136.205.189', '1533310910', 'tQ5b646f2c8fbab', null);

-- ----------------------------
-- Table structure for `ds_order`
-- ----------------------------
DROP TABLE IF EXISTS `ds_order`;
CREATE TABLE `ds_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(100) DEFAULT NULL,
  `userid` int(10) DEFAULT NULL,
  `zyid` int(10) DEFAULT NULL,
  `orderid` varchar(100) DEFAULT NULL,
  `shijian` int(10) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `suoyin1` (`orderid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10016 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_order
-- ----------------------------
INSERT INTO `ds_order` VALUES ('10015', '219.136.205.189', '10005', '10011', 'V2BaDunywuAtjW1000520180803235740', '1533311860', '3.00');

-- ----------------------------
-- Table structure for `ds_pay`
-- ----------------------------
DROP TABLE IF EXISTS `ds_pay`;
CREATE TABLE `ds_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL COMMENT '用户ID',
  `money` varchar(255) DEFAULT NULL COMMENT '提现金额',
  `zt` varchar(255) DEFAULT NULL COMMENT '提现状态',
  `shijian` varchar(255) DEFAULT NULL COMMENT '提现时间',
  `name` varchar(255) DEFAULT NULL,
  `zhanghao` varchar(255) DEFAULT NULL,
  `leixing` varchar(255) DEFAULT NULL,
  `type` int(1) DEFAULT '0',
  `imgurl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_pay
-- ----------------------------
INSERT INTO `ds_pay` VALUES ('1', '1', '122', '已支付', '123123', '123123', '123', '123', '0', '123');

-- ----------------------------
-- Table structure for `ds_siyou`
-- ----------------------------
DROP TABLE IF EXISTS `ds_siyou`;
CREATE TABLE `ds_siyou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `money` varchar(255) DEFAULT NULL COMMENT '资源设置的打赏金额',
  `sj` varchar(255) DEFAULT NULL COMMENT '选择模式 1为 开启随机金额分配',
  `cs` int(10) DEFAULT '0' COMMENT '打赏人数',
  `url` varchar(1000) DEFAULT NULL COMMENT '打赏图片',
  `userid` varchar(255) DEFAULT NULL COMMENT '用户ID',
  `name` varchar(255) DEFAULT NULL COMMENT '资源名称',
  `zykey` varchar(1000) DEFAULT NULL,
  `shijian` varchar(255) DEFAULT NULL,
  `pid` int(10) DEFAULT '0',
  `photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10012 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_siyou
-- ----------------------------
INSERT INTO `ds_siyou` VALUES ('10010', '3', '3', '0', '1', '10005', '1', '4d35a982a31ad75c0775829a80faf998', '2018-08-03 23:42:08', '10004', '1');
INSERT INTO `ds_siyou` VALUES ('10011', '3', '3', '0', '1', '10005', '1', '7055429bb1343e21687570a186bda365', '2018-08-03 23:42:08', '10005', '1');

-- ----------------------------
-- Table structure for `ds_ts`
-- ----------------------------
DROP TABLE IF EXISTS `ds_ts`;
CREATE TABLE `ds_ts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `zt` varchar(255) DEFAULT NULL,
  `neirong` varchar(255) DEFAULT NULL,
  `shijian` varchar(255) DEFAULT NULL,
  `typeto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_ts
-- ----------------------------

-- ----------------------------
-- Table structure for `ds_tui`
-- ----------------------------
DROP TABLE IF EXISTS `ds_tui`;
CREATE TABLE `ds_tui` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_tui
-- ----------------------------
INSERT INTO `ds_tui` VALUES ('16', '10005', 'www.baidu.com');

-- ----------------------------
-- Table structure for `ds_tupian`
-- ----------------------------
DROP TABLE IF EXISTS `ds_tupian`;
CREATE TABLE `ds_tupian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_tupian
-- ----------------------------

-- ----------------------------
-- Table structure for `ds_yqm`
-- ----------------------------
DROP TABLE IF EXISTS `ds_yqm`;
CREATE TABLE `ds_yqm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL,
  `yqm` varchar(255) DEFAULT NULL,
  `shijian` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `zt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10010 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_yqm
-- ----------------------------
INSERT INTO `ds_yqm` VALUES ('10008', '10004', 'Gn16455b646deb4a8e743', '2018-08-03 22:59:55', null, '未使用');
INSERT INTO `ds_yqm` VALUES ('10009', '10004', 'tQ5b646f2c8fbab', '2018-08-03 23:05:16', 'yuyusqq', '已使用');

-- ----------------------------
-- Table structure for `ds_zhifu`
-- ----------------------------
DROP TABLE IF EXISTS `ds_zhifu`;
CREATE TABLE `ds_zhifu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ds_zhifu
-- ----------------------------
INSERT INTO `ds_zhifu` VALUES ('1', 'a:1:{s:4:\"ukey\";s:1:\"1\";}');
