<html class="no-js css-menubar" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>微信支付流程说明</title>
	<link rel="stylesheet" href="wapcss/bootstrap.css">
    <link rel="stylesheet" href="wapcss/bootstrap-extend.css">
    <link rel="stylesheet" href="wapcss/site.css">
	<script type="text/javascript" src="wapcss/jquery-2.1.1.min.js"></script>
</head>
  <body class="page-maintenance layout-full">
    <div class="page animsition text-center" style="-webkit-animation: 800ms; opacity: 1;">
      <div class="page-content vertical-align-middle">
          <!-- Qpay -->
          <div id="pjax" class="container">

		      <div>
              <div><div style="background-color:#019901">
                <font face="微软雅黑" style="font-weight:900;" color="#ffffff"><b style="font-weight:900;"><b style="font-weight:900; font-size:22px;"><p>微信扫码支付：</p></b>1.微信扫码支付需要先保存此二维码到相册，长按显示的二维码图片可以保存图片，也可以直接采用截屏保存图片到相册。</b></font></div></div>
            </div>

            <div class="row paypage-logo">
              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 paypage-logorow">
                <div style="width:100%;"><img src="css/wxexp01.jpg" width="100%"></div></div>
            </div>
			
			<div>
			
            <div><div style="background-color:#019901">
                <font face="微软雅黑" style="font-weight:900;" color="#ffffff"><b style="font-weight:900; font-size:22px;">2.打开手机微信，点右上角“＋” 选扫一扫</b></font></div></div>
            </div>
			
			<div class="row paypage-logo">
              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 paypage-logorow">
                <div style="width:100%;"><img src="css/wxexp02.jpg" width="100%"></div></div>
            </div>
			
			<div><div style="background-color:#019901">
                <font face="微软雅黑" style="font-weight:900;" color="#ffffff"><b style="font-weight:900; font-size:22px;">3.点右上角三个竖点后下面会显示从相册选取二维码，点击文字后弹出手机相册，选择刚刚保存的二维码图片</b></font></div></div>
            </div>
			
			<div class="row paypage-logo">
              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 paypage-logorow">
                <div style="width:100%;"><img src="css/wxexp03.jpg" width="100%"></div></div>
            </div>
			
			<div class="row paypage-logo">
              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 paypage-logorow">
                <div style="width:100%;"><img src="css/wxexp04.jpg" width="100%"></div></div>
            </div>
			
			<div class="row paypage-logo">
              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 paypage-logorow">
                <div style="width:100%;"><img src="css/wxexp05.jpg" width="100%"></div></div>
            </div>
			
			<div><div style="background-color:#019901">
                <font face="微软雅黑" style="font-weight:900;" color="#ffffff"><b style="font-weight:900; font-size:22px;">4.识别二维码图片后进行支付，返回网站支付成功。</b></font></div></div>
            </div>
			
			<div class="row paypage-logo">
              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 paypage-logorow">
                <div style="width:100%;"><img src="css/wxexp06.jpg" width="100%"></div></div>
            </div>
			
            <div class="row paypage-info">
              <div class="col-lg-2 col-md-3 col-xs-2 clearfix">
              </div>
            </div>
			
            <div class="row">
		</div>
	  </div>
    </div>  
	
<footer class="site-footer">
<div class="site-footer-legal"></div>
<div class="site-footer-right"></div>
</footer>
</div>
</body></html>
