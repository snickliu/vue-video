<?php	if(!defined('IN_UOZHIFU')) exit('Request Error!');

$ewmjiexiurl = '../ewmimages/';
$cfg_webswitch = 'Y';
$cfg_webname = '管理系统';
$ewmadminurl = 'ewmadmin';
$ldpayoff = '0';
$accounttype = '1';
$renyitype = '0';
$keytype = '0';
$httptype = '0';
$payok2018type = '0';
$ewmjiexi = '0';
$aliewmok = '0';
$wxqqewmok = '0';
$ewmposttype = '3';
$xianail = '1';
$xiancft = '1';
$xianwx = '1';
$cfg_mysql_type = 'mysqli';
$cfg_pagenum = '10';
$cfg_timezone = '8';
$cfg_diserror = 'N';

?>