<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>微信二维码制作及上传帮助！</title>
<meta name="description" content="微信二维码制作及上传帮助！">
<link rel="stylesheet" type="text/css" href="images/style.css">
<link rel="stylesheet" type="text/css" href="images/shCoreDefault.css">
<style type="text/css">
.img_switch {margin:0 auto;WIDTH:1000px;HEIGHT: 261px; overflow:hidden}
.img_switch_content {HEIGHT: 261px;position:relative;}
.img_switch_text {width: 262px;position: absolute;z-index:10; bottom:5px;left:10px;HEIGHT: 15px; z-index:10000 !important}
.number_nav {DISPLAY: inline;FLOAT: left;}
.number_nav UL {font:12px Arial, Helvetica, sans-serif;padding: 0px;MARGIN: 0px;LIST-STYLE-TYPE: none;color:#fff;}
.number_nav UL LI {float: left;font-weight: bold;background: #000;float: left;margin-right: 8px;width: 23px;cursor: pointer;line-height: 17px;height: 17px;text-align: center;filter:alpha(opacity=75);-moz-opacity:0.75;opacity: 0.75;}
#pic {OVERFLOW: hidden}
.STYLE1 {	font-family: "宋体";
	font-size: 21px;
	color: red;
}
.STYLE2 {color: red}
.STYLE3 {font-family: "宋体";
	font-size: 21px;
}
.STYLE4 {
	color: #FF0000;
	font-weight: bold;
}
.STYLE5 {color: #FF0000; font-weight: bold; font-size: 36px; }
</style></head>

<body>
<div class="content" style="padding-top:20px;">
  <div class="main">

    <div class="leftx">
      <div class="main_content">
        <h2 class="title4">微信二维码制作及上传帮助！</h2>
        <div class="title5"></div>
        <p></p><p><span style="color: rgb(69, 69, 69); font-family: ??????, Arial, Helvetica, sans-serif; font-size: 12px; line-height: 20px; background-color: rgb(240, 240, 240);">第一步，打开微信制作二维码。</span></p><p align="center"><img src="images/30.jpg" width="842" height="671" /></p>
        <p align="center"><span style="font-size: 21px;font-family: 宋体">微信二维码生成设置金额</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span style="font-size: 21px;font-family: 宋体">例如：</span><span style="font-size: 21px">1</span><span style="font-size: 21px;font-family: 宋体">元分组</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span class="STYLE1">1.01</span></p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: 'Times New Roman';white-space: normal"><span style="font-family: &quot;宋体&quot;">1.02</span></p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: 'Times New Roman';white-space: normal"><span style="font-family: &quot;宋体&quot;">1.03</span></p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: 'Times New Roman';white-space: normal"><span style="font-family: &quot;宋体&quot;">1.04</span></p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: 'Times New Roman';white-space: normal"><span style="font-family: &quot;宋体&quot;">1.05</span></p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: &quot;宋体&quot;;white-space: normal">...</p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: &quot;宋体&quot;;white-space: normal">1.09</p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal">每组最大到09，一般收款不是很频繁正常设置到05就可以了</p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span style="font-size: 21px;font-family: 宋体">例如：</span><span style="font-size: 21px">10</span><span style="font-size: 21px;font-family: 宋体">元分组</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span class="STYLE1">10.01</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span class="STYLE1">10.02</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span class="STYLE1">10.0</span><span class="STYLE1">3</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span class="STYLE2" style=";text-align: center;font-size: 21px;font-family: &quot;宋体&quot;;white-space: normal">...</span></p>
        <p class="STYLE2" style=";text-align: center;font-size: 21px;font-family: 'Times New Roman';white-space: normal"><span style="font-family: &quot;宋体&quot;">10.09</span></p>
        <p align="center"><span style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span style="font-size: 21px;font-family: 宋体">把生成好的二维码发送到电脑进行下一步处理</span></span></p>
        <p align="center"><span style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span style="font-size: 21px;font-family: 宋体">例如这</span><span style="font-size: 21px">5</span><span style="font-size: 21px;font-family: 宋体">个</span><span style="font-size: 21px">1</span><span style="font-size: 21px;font-family: 宋体">元二维码</span></span></p>
        <p align="center"><img src="images/31.jpg" width="677" height="348" /></p>
        <p align="center"><span class="STYLE3">用QQ截图 截下二维码后保存对应文件名称待用</span></p>
        <p align="center"><img src="images/32.jpg" width="867" height="481" /></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal">比如这个10元组二维码，把二维码剪切下来保存文件名对应二维码的备注，这个保存为10.01.jpg依此类推。</p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span class="STYLE3">下图是已经截好的五个二维码图片</span></p>
        <p align="center"><img src="images/33.jpg" width="646" height="272" /></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span style="font-size: 21px;font-family: 宋体">登陆二维码管理系统上传二维码</span></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/20180311152043.jpg" width="621" height="275" /></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/20180311152207.png" width="475" height="304" /></p>
        <p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/20180311152912.jpg" width="564" height="229" /></p>
        <p align="center" style="font-size: 14px; font-family: 'Times New Roman'; white-space: normal;">&nbsp;</p>
        <div align="center"><img src="images/34.jpg" width="514" height="266" />
        </div>
        <p align="center">&nbsp;</p>
        <p align="center"><img src="images/35.jpg" width="747" height="235" /></p>
        <p align="center"><span style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><span style="font-size: 21px;font-family: 宋体">点击进入</span><span style="font-size: 21px">微信10</span><span style="font-size: 21px;font-family: 宋体">元二维码管理</span></span></p>
        <p align="center"><img src="images/36.jpg" width="753" height="242" /></p>
        <p align="center"><img src="images/37.jpg" width="894" height="528" /></p>
        <p align="center" class="STYLE5">必须要仔细看懂下面这句</p>
        <p align="center" class="STYLE4"><span style="font-size: 21px">二维码设置的金额和当前二维码系统里的 备注理由必须保持一致，否则将不能到账。</span></p>
        <p align="center"><img src="images/38.jpg" width="740" height="356" /></p>
        <p align="center"><span style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal">上传好了5个10元组的二维码的效果，备注理由要按照顺序填加。</span></p>
        <p>注意：每组最好不要少于5个二维码，比如 &nbsp;10.01 &nbsp; 10.02 &nbsp; 10.03 &nbsp; 10.04 &nbsp; 10.05 最大支持 到 10.09</p>
        <p>为什么会在金额后方加上数，这是为了能自动到账，作为编号使用。</p>
        <p>金额不限制 可以 11.01-09，189.01-09 等等....</p>
        <p>如有疑问请联系网站客服QQ</p>
        <p align="center"><span style="color: rgb(69, 69, 69); font-family: ??????, Arial, Helvetica, sans-serif; font-size: 12px; line-height: 20px; background-color: rgb(240, 240, 240);"><br>
        </span><br>
        </p>
      </div>
    </div>
   
    <div class="clear"></div>
  </div>
</div>
<div class="foot"><br>
  <div class="clear"></div>
</div>
<div style="display:none">
</div>


</body></html>