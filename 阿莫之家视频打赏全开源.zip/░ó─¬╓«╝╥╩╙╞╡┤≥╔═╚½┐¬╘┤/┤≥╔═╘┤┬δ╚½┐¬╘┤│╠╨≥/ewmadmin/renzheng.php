<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>微信配置认证登陆方法</title>
<meta name="description" content="微信配置认证登陆方法">
<link rel="stylesheet" type="text/css" href="images/style.css">
<link rel="stylesheet" type="text/css" href="images/shCoreDefault.css">
<style type="text/css">
.img_switch {margin:0 auto;WIDTH:1000px;HEIGHT: 261px; overflow:hidden}
.img_switch_content {HEIGHT: 261px;position:relative;}
.img_switch_text {width: 262px;position: absolute;z-index:10; bottom:5px;left:10px;HEIGHT: 15px; z-index:10000 !important}
.number_nav {DISPLAY: inline;FLOAT: left;}
.number_nav UL {font:12px Arial, Helvetica, sans-serif;padding: 0px;MARGIN: 0px;LIST-STYLE-TYPE: none;color:#fff;}
.number_nav UL LI {float: left;font-weight: bold;background: #000;float: left;margin-right: 8px;width: 23px;cursor: pointer;line-height: 17px;height: 17px;text-align: center;filter:alpha(opacity=75);-moz-opacity:0.75;opacity: 0.75;}
#pic {OVERFLOW: hidden}
.STYLE1 {
	font-family: "宋体";
	font-size: 21px;
}
</style></head>
<body>
<div class="content" style="padding-top:20px;">
  <div class="main">
    <div class="leftx">
      <div class="main_content">
        <h2 class="title4">微信软件配置及认证登陆方法</h2>
        <p style=";text-align: center;font-size: 14px;font-family: &#39;Times New Roman&#39;;white-space: normal">&nbsp;</p>
		<p style=";text-align: center;font-size: 14px;font-family: &#39;Times New Roman&#39;;white-space: normal"><span style="font-size: 21px"><img src="images/rz01.jpg" width="556" height="786" /></span></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz02.jpg" width="557" height="749" /></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz031.jpg" width="556" height="689" /></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz03.jpg" width="556" height="689" /></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz041.gif" width="558" height="583" /></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz051.jpg" width="604" height="704" /></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz061.gif" width="558" height="732" /></p>
		<p style=";text-align: center;font-size: 14px;font-family: 'Times New Roman';white-space: normal"><img src="images/rz071.gif" width="558" height="589" /></p>
		<p><br></p><p></p>
      </div>
    </div>
   
    <div class="clear"></div>
  </div>
</div>
<div class="foot"><br>
  <div class="clear"></div>
</div>
</body></html>